function acao(){
    let modal = document.querySelector('.modal')
    modal.style.display = 'block';
}

function fechar(){
    let modal = document.querySelector('.modal')
    modal.style.display = 'none';
}